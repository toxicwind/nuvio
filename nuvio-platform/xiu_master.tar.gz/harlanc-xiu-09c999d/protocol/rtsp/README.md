A rtsp library.

