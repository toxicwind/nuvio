import "mediaelement";
import "mediaelement/build/mediaelementplayer.min.css";
import { useEffect, useRef, useState } from "react";
import Hls from "hls.js";
import { HlsJsP2PEngine, HlsWithP2PInstance } from "p2p-media-loader-hlsjs";
import { createVideoElements, subscribeToUiEvents } from "../utils";
import { PlayerProps } from "../../../types";

export const HlsjsMediaElement = ({
  streamUrl,
  coreOptions,
  onPeerConnect,
  onPeerClose,
  onChunkDownloaded,
  onChunkUploaded,
}: PlayerProps) => {
  const [isHlsSupported, setIsHlsSupported] = useState(true);

  const containerRef = useRef<HTMLDivElement>(null);
  /* eslint-disable  */
  // @ts-ignore
  useEffect(() => {
    if (!containerRef.current) return;
    if (!Hls.isSupported()) {
      setIsHlsSupported(false);
      return;
    }

    const { videoContainer, videoElement } = createVideoElements();

    containerRef.current.appendChild(videoContainer);

    const prevHls = window.Hls;
    window.Hls = HlsJsP2PEngine.injectMixin(Hls);

    // @ts-ignore
    const player = new MediaElementPlayer(videoElement.id, {
      iconSprite: "/mejs-controls.svg",
      videoHeight: "100%",
      hls: {
        p2p: {
          onHlsJsCreated: (hls: HlsWithP2PInstance<Hls>) => {
            subscribeToUiEvents({
              engine: hls.p2pEngine,
              onPeerConnect,
              onPeerClose,
              onChunkDownloaded,
              onChunkUploaded,
            });
          },
          core: coreOptions,
        },
      },
    });

    player.setSrc(streamUrl);
    player.load();

    return () => {
      window.Hls = prevHls;
      player?.remove();
      videoContainer.remove();
    };
    /* eslint-enable  */
  }, [
    coreOptions,
    onChunkDownloaded,
    onChunkUploaded,
    onPeerConnect,
    onPeerClose,
    streamUrl,
  ]);

  return isHlsSupported ? (
    <div ref={containerRef} />
  ) : (
    <div className="error-message">
      <h3>HLS is not supported in this browser</h3>
    </div>
  );
};
