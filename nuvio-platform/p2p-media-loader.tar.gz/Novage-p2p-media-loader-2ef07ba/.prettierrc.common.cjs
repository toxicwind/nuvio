module.exports = {
  editorconfig: true,
};
