import os
import random
import secrets
import string
import time
from collections.abc import Awaitable, Callable
from typing import List, Optional, Union

import RTN
from databases import Database
from databases.backends.sqlite import SQLiteConnection
from pydantic import BaseModel, Field, field_validator
from pydantic_settings import BaseSettings, SettingsConfigDict
from RTN import DefaultRanking, SettingsModel
from RTN.models import (AudioRankModel, CustomRank, CustomRanksConfig,
                        ExtrasRankModel, HdrRankModel, LanguagesConfig,
                        OptionsConfig, QualityRankModel, ResolutionConfig,
                        RipsRankModel)

from comet.core.db_router import ReplicaAwareDatabase
from comet.core.logger import logger

_comet_fk_enabled = False
_SQLITE_BUSY_TIMEOUT_MS = 30000


def set_comet_foreign_keys_enabled(enabled: bool) -> None:
    global _comet_fk_enabled
    _comet_fk_enabled = enabled


async def apply_sqlite_connection_pragmas(
    execute: Callable[[str], Awaitable[object]],
    *,
    foreign_keys_enabled: bool,
) -> None:
    await execute(f"PRAGMA busy_timeout={_SQLITE_BUSY_TIMEOUT_MS}")
    await execute(f"PRAGMA foreign_keys={'ON' if foreign_keys_enabled else 'OFF'}")


if not getattr(SQLiteConnection, "_comet_pragmas_patched", False):
    _original_sqlite_acquire = SQLiteConnection.acquire

    async def _comet_sqlite_acquire(self):
        await _original_sqlite_acquire(self)
        assert self._connection is not None
        await apply_sqlite_connection_pragmas(
            self._connection.execute,
            foreign_keys_enabled=_comet_fk_enabled,
        )

    SQLiteConnection.acquire = _comet_sqlite_acquire
    SQLiteConnection._comet_pragmas_patched = True


class AppSettings(BaseSettings):
    model_config = SettingsConfigDict(
        env_file=".env", env_file_encoding="utf-8", extra="allow"
    )

    ADDON_ID: Optional[str] = "stremio.comet.fast"
    ADDON_NAME: Optional[str] = "Comet"
    FASTAPI_HOST: Optional[str] = "0.0.0.0"
    FASTAPI_PORT: Optional[int] = 8000
    FASTAPI_WORKERS: Optional[int] = 1
    USE_GUNICORN: Optional[bool] = True
    GUNICORN_PRELOAD_APP: Optional[bool] = True
    EXECUTOR_MAX_WORKERS: Optional[int] = 1
    ADMIN_DASHBOARD_PASSWORD: Optional[str] = "".join(
        random.choices(string.ascii_letters + string.digits, k=16)
    )
    ADMIN_DASHBOARD_SESSION_TTL: Optional[int] = 86400
    CONFIGURE_PAGE_PASSWORD: Optional[str] = None
    CONFIGURE_PAGE_SESSION_TTL: Optional[int] = 86400
    PUBLIC_API_TOKEN: Optional[str] = None
    PUBLIC_API_TOKEN_FILE: Optional[str] = "data/public_api_token.txt"
    PUBLIC_METRICS_API: Optional[bool] = False
    DATABASE_TYPE: Optional[str] = "sqlite"
    DATABASE_URL: Optional[str] = "username:password@hostname:port"
    DATABASE_PATH: Optional[str] = "data/comet.db"
    DATABASE_BATCH_SIZE: Optional[int] = 20000
    DATABASE_READ_REPLICA_URLS: List[str] = Field(default_factory=list)
    DATABASE_STARTUP_CLEANUP_INTERVAL: Optional[int] = 3600
    MEMORY_TRIM_INTERVAL: Optional[int] = 300
    DATABASE_FORCE_IPV4_RESOLUTION: Optional[bool] = False
    METADATA_CACHE_TTL: Optional[int] = 2592000  # 30 days
    TORRENT_CACHE_TTL: Optional[int] = 2592000  # 30 days
    LIVE_TORRENT_CACHE_TTL: Optional[int] = 604800  # 7 days
    DEBRID_CACHE_TTL: Optional[int] = 86400  # 1 day
    METRICS_CACHE_TTL: Optional[int] = 60  # 1 minute
    DEBRID_CACHE_CHECK_RATIO: Optional[float] = 0.0  # 0.0 to 1.0
    SCRAPE_LOCK_TTL: Optional[int] = 300  # 5 minutes
    SCRAPE_WAIT_TIMEOUT: Optional[int] = (
        30  # Max time to wait for other instance to complete
    )
    INDEXER_MANAGER_TYPE: Optional[str] = None
    INDEXER_MANAGER_URL: Optional[str] = "http://127.0.0.1:9117"
    INDEXER_MANAGER_API_KEY: Optional[str] = None
    INDEXER_MANAGER_MODE: Union[bool, str] = "both"
    INDEXER_MANAGER_TIMEOUT: Optional[int] = 30
    INDEXER_MANAGER_INDEXERS: List[str] = []
    INDEXER_MANAGER_UPDATE_INTERVAL: Optional[int] = 900
    INDEXER_MANAGER_WAIT_TIMEOUT: Optional[int] = 30
    SCRAPE_JACKETT: Union[bool, str] = False
    JACKETT_URL: Optional[str] = "http://127.0.0.1:9117"
    JACKETT_API_KEY: Optional[str] = None
    JACKETT_INDEXERS: List[str] = []
    SCRAPE_PROWLARR: Union[bool, str] = False
    PROWLARR_URL: Optional[str] = "http://127.0.0.1:9696"
    PROWLARR_API_KEY: Optional[str] = None
    PROWLARR_INDEXERS: List[str] = []
    GET_TORRENT_TIMEOUT: Optional[int] = 5
    MAGNET_RESOLVE_TIMEOUT: Optional[int] = 60
    CATALOG_TIMEOUT: Optional[int] = 30
    DOWNLOAD_TORRENT_FILES: Optional[bool] = False
    SCRAPE_COMET: Union[bool, str] = False
    COMET_URL: Union[str, List[str]] = "https://comet.feels.legal"
    COMET_CLEAN_TRACKER: Optional[bool] = False
    SCRAPE_NYAA: Union[bool, str] = False
    NYAA_ANIME_ONLY: Optional[bool] = True
    NYAA_MAX_CONCURRENT_PAGES: Optional[int] = 5
    SCRAPE_ANIMETOSHO: Union[bool, str] = False
    ANIMETOSHO_ANIME_ONLY: Optional[bool] = True
    ANIMETOSHO_MAX_CONCURRENT_PAGES: Optional[int] = 10
    SCRAPE_SEADEX: Union[bool, str] = False
    SEADEX_ANIME_ONLY: Optional[bool] = True
    SCRAPE_NEKOBT: Union[bool, str] = False
    NEKOBT_ANIME_ONLY: Optional[bool] = True
    SCRAPE_ZILEAN: Union[bool, str] = False
    ZILEAN_URL: Union[str, List[str]] = "https://zileanfortheweebs.midnightignite.me"
    SCRAPE_STREMTHRU: Union[bool, str] = False
    STREMTHRU_SCRAPE_URL: Union[str, List[str]] = "https://stremthru.13377001.xyz"
    SCRAPE_DMM: Union[bool, str] = False
    DMM_INGEST_ENABLED: Optional[bool] = False
    DMM_INGEST_INTERVAL: Optional[int] = 86400
    DMM_INGEST_CONCURRENT_WORKERS: Optional[int] = 4
    DMM_INGEST_BATCH_SIZE: Optional[int] = 100
    SCRAPE_BITMAGNET: Union[bool, str] = False
    BITMAGNET_URL: Union[str, List[str]] = (
        "https://bitmagnetfortheweebs.midnightignite.me"
    )
    BITMAGNET_MAX_CONCURRENT_PAGES: Optional[int] = 5
    BITMAGNET_MAX_OFFSET: Optional[int] = 15000
    SCRAPE_TORRENTIO: Union[bool, str] = False
    TORRENTIO_URL: Union[str, List[str]] = "https://torrentio.strem.fun"
    SCRAPE_MEDIAFUSION: Union[bool, str] = False
    MEDIAFUSION_URL: Union[str, List[str]] = "https://mediafusion.elfhosted.com"
    MEDIAFUSION_API_PASSWORD: Union[str, List[str], None] = None
    MEDIAFUSION_LIVE_SEARCH: Optional[bool] = True
    SCRAPE_AIOSTREAMS: Union[bool, str] = False
    AIOSTREAMS_URL: Optional[Union[str, List[str]]] = None
    AIOSTREAMS_USER_UUID_AND_PASSWORD: Union[str, List[str], None] = None
    SCRAPE_JACKETTIO: Union[bool, str] = False
    JACKETTIO_URL: Optional[Union[str, List[str]]] = None
    SCRAPE_DEBRIDIO: Union[bool, str] = False
    DEBRIDIO_API_KEY: Optional[str] = None
    DEBRIDIO_PROVIDER: Optional[str] = None
    DEBRIDIO_PROVIDER_KEY: Optional[str] = None
    SCRAPE_TORBOX: Union[bool, str] = False
    TORBOX_API_KEY: Optional[str] = None
    SCRAPE_TORRENTSDB: Union[bool, str] = False
    SCRAPE_PEERFLIX: Union[bool, str] = False
    CUSTOM_HEADER_HTML: Optional[str] = None
    PROXY_DEBRID_STREAM: Optional[bool] = False
    PROXY_DEBRID_STREAM_PASSWORD: Optional[str] = "".join(
        random.choices(string.ascii_letters + string.digits, k=16)
    )
    PROXY_DEBRID_STREAM_MAX_CONNECTIONS: Optional[int] = -1
    PROXY_DEBRID_STREAM_DEBRID_DEFAULT_SERVICE: Optional[str] = "realdebrid"
    PROXY_DEBRID_STREAM_DEBRID_DEFAULT_APIKEY: Optional[str] = None
    PROXY_DEBRID_STREAM_INACTIVITY_THRESHOLD: Optional[int] = 300
    DEBRID_ACCOUNT_SCRAPE_REFRESH_INTERVAL: int = 900
    DEBRID_ACCOUNT_SCRAPE_CACHE_TTL: int = 86400
    DEBRID_ACCOUNT_SCRAPE_MAX_SNAPSHOT_ITEMS: int = 5000
    DEBRID_ACCOUNT_SCRAPE_MAX_MATCH_ITEMS: int = 1500
    DEBRID_ACCOUNT_SCRAPE_INITIAL_WARM_TIMEOUT: float = 5.0
    STREMTHRU_URL: Optional[str] = "https://stremthru.13377001.xyz"
    DISABLE_TORRENT_STREAMS: Optional[bool] = False
    TORRENT_DISABLED_STREAM_NAME: Optional[str] = "[INFO] Comet"
    TORRENT_DISABLED_STREAM_DESCRIPTION: Optional[str] = (
        "Direct torrent playback is disabled on this server."
    )
    TORRENT_DISABLED_STREAM_URL: Optional[str] = "https://comet.feels.legal"
    PUBLIC_BASE_URL: Optional[str] = None
    REMOVE_ADULT_CONTENT: Optional[bool] = False
    BACKGROUND_SCRAPER_ENABLED: Optional[bool] = False
    BACKGROUND_SCRAPER_CONCURRENT_WORKERS: Optional[int] = 1
    BACKGROUND_SCRAPER_INTERVAL: Optional[int] = 3600
    BACKGROUND_SCRAPER_MAX_MOVIES_PER_RUN: Optional[int] = 100
    BACKGROUND_SCRAPER_MAX_SERIES_PER_RUN: Optional[int] = 100
    BACKGROUND_SCRAPER_SUCCESS_TTL: Optional[int] = 604800
    BACKGROUND_SCRAPER_FAILURE_BASE_BACKOFF: Optional[int] = 3600
    BACKGROUND_SCRAPER_FAILURE_MAX_BACKOFF: Optional[int] = 604800
    BACKGROUND_SCRAPER_MAX_RETRIES: Optional[int] = 6
    BACKGROUND_SCRAPER_RUN_TIME_BUDGET: Optional[int] = 1800
    BACKGROUND_SCRAPER_DISCOVERY_MULTIPLIER: Optional[int] = 3
    BACKGROUND_SCRAPER_MAX_EPISODES_PER_SERIES_PER_RUN: Optional[int] = 25
    BACKGROUND_SCRAPER_EPISODE_REFRESH_TTL: Optional[int] = 21600
    BACKGROUND_SCRAPER_ENABLE_DEMAND_PRIORITY: Optional[bool] = True
    BACKGROUND_SCRAPER_DEMAND_LOOKBACK: Optional[int] = 86400
    BACKGROUND_SCRAPER_DEFER_COOLDOWN: Optional[int] = 300
    BACKGROUND_SCRAPER_MIN_PRIORITY_SCORE: Optional[float] = 0.0
    BACKGROUND_SCRAPER_PRIORITY_DECAY_ON_MISS: Optional[float] = 0.9
    BACKGROUND_SCRAPER_QUEUE_LOW_WATERMARK: Optional[int] = 10000
    BACKGROUND_SCRAPER_QUEUE_HIGH_WATERMARK: Optional[int] = 20000
    BACKGROUND_SCRAPER_QUEUE_HARD_CAP: Optional[int] = 30000
    BACKGROUND_SCRAPER_ALERT_FAIL_RATE: Optional[float] = 0.7
    BACKGROUND_SCRAPER_ALERT_QUEUE_AGE: Optional[int] = 86400
    BACKGROUND_SCRAPER_RUN_RETENTION_DAYS: Optional[int] = 30
    ANIME_MAPPING_ENABLED: Optional[bool] = True
    ANIME_MAPPING_REFRESH_INTERVAL: Optional[int] = 432000
    DIGITAL_RELEASE_FILTER: Optional[bool] = False
    TMDB_READ_ACCESS_TOKEN: Optional[str] = None
    GLOBAL_PROXY_URL: Optional[str] = None
    PROXY_ETHOS: Optional[str] = "always"
    RATELIMIT_MAX_RETRIES: Optional[int] = 3
    RATELIMIT_RETRY_BASE_DELAY: Optional[float] = 1.0
    RTN_FILTER_DEBUG: Optional[bool] = False
    FILTER_PARSE_CACHE_SIZE: Optional[int] = 10000
    FILTER_PARSE_CACHE_SHARDS: Optional[int] = 8
    FILTER_PARSE_CACHE_DEDUP_INFLIGHT: Optional[bool] = True
    HTTP_CACHE_ENABLED: Optional[bool] = False
    HTTP_CLIENT_LIMIT: Optional[int] = 100
    HTTP_CLIENT_LIMIT_PER_HOST: Optional[int] = 20
    HTTP_CLIENT_TTL_DNS_CACHE: Optional[int] = 300
    HTTP_CLIENT_KEEPALIVE_TIMEOUT: Optional[float] = 30.0
    HTTP_CLIENT_TIMEOUT_TOTAL: Optional[float] = 30.0
    HTTP_CACHE_STREAMS_TTL: Optional[int] = 300
    HTTP_CACHE_STALE_WHILE_REVALIDATE: Optional[int] = 60
    HTTP_CACHE_MANIFEST_TTL: Optional[int] = 86400
    HTTP_CACHE_CONFIGURE_TTL: Optional[int] = 86400
    DOWNLOAD_GENERIC_TRACKERS: Optional[bool] = False
    SMART_LANGUAGE_DETECTION: Optional[bool] = False

    # CometNet P2P Network Configuration
    COMETNET_ENABLED: Optional[bool] = False
    COMETNET_LISTEN_PORT: Optional[int] = 8765
    COMETNET_HTTP_PORT: Optional[int] = 8766
    COMETNET_BOOTSTRAP_NODES: List[str] = []
    COMETNET_MANUAL_PEERS: List[str] = []
    COMETNET_MAX_PEERS: Optional[int] = 50
    COMETNET_MIN_PEERS: Optional[int] = 3
    COMETNET_KEYS_DIR: Optional[str] = "data/cometnet"
    COMETNET_ADVERTISE_URL: Optional[str] = None
    COMETNET_KEY_PASSWORD: Optional[str] = None
    COMETNET_ALLOW_PRIVATE_PEX: Optional[bool] = False
    COMETNET_SKIP_REACHABILITY_CHECK: Optional[bool] = False
    COMETNET_SKIP_TIME_CHECK: Optional[bool] = False
    COMETNET_TIME_CHECK_TOLERANCE: Optional[int] = 60
    COMETNET_TIME_CHECK_TIMEOUT: Optional[int] = 5
    COMETNET_REACHABILITY_RETRIES: Optional[int] = 5
    COMETNET_REACHABILITY_RETRY_DELAY: Optional[int] = 10
    COMETNET_REACHABILITY_TIMEOUT: Optional[int] = 10
    COMETNET_UPNP_ENABLED: Optional[bool] = False
    COMETNET_UPNP_LEASE_DURATION: Optional[int] = 3600
    COMETNET_RELAY_URL: Optional[str] = None
    COMETNET_API_KEY: Optional[str] = "".join(
        random.choices(string.ascii_letters + string.digits, k=16)
    )  # API key for standalone service auth
    COMETNET_STATE_SAVE_INTERVAL: Optional[int] = (
        300  # Periodic state save interval in seconds (5 minutes)
    )

    # CometNet Gossip Tuning
    COMETNET_GOSSIP_FANOUT: Optional[int] = 3
    COMETNET_GOSSIP_INTERVAL: Optional[float] = 1.0
    COMETNET_GOSSIP_MESSAGE_TTL: Optional[int] = 5
    COMETNET_GOSSIP_MAX_TORRENTS_PER_MESSAGE: Optional[int] = 1000

    COMETNET_GOSSIP_VALIDATION_FUTURE_TOLERANCE: Optional[int] = 60
    COMETNET_GOSSIP_VALIDATION_PAST_TOLERANCE: Optional[int] = 300
    COMETNET_GOSSIP_TORRENT_MAX_AGE: Optional[int] = 604800

    # CometNet Discovery Tuning
    COMETNET_PEX_BATCH_SIZE: Optional[int] = 20
    COMETNET_PEER_CONNECT_BACKOFF_MAX: Optional[int] = 300
    COMETNET_PEER_MAX_FAILURES: Optional[int] = 5
    COMETNET_PEER_CLEANUP_AGE: Optional[int] = 604800

    # CometNet Transport Tuning
    COMETNET_TRANSPORT_MAX_MESSAGE_SIZE: Optional[int] = 10485760  # 10MB
    COMETNET_TRANSPORT_MAX_CONNECTIONS_PER_IP: Optional[int] = 3
    COMETNET_TRANSPORT_PING_INTERVAL: Optional[float] = 30.0
    COMETNET_TRANSPORT_CONNECTION_TIMEOUT: Optional[float] = 120.0
    COMETNET_TRANSPORT_MAX_LATENCY_MS: Optional[float] = (
        10000.0  # Max acceptable latency before disconnection
    )
    COMETNET_TRANSPORT_WEBSOCKET_COMPRESSION_ENABLED: Optional[bool] = False
    COMETNET_TRANSPORT_RATE_LIMIT_ENABLED: Optional[bool] = True
    COMETNET_TRANSPORT_RATE_LIMIT_COUNT: Optional[int] = 20  # Messages per window
    COMETNET_TRANSPORT_RATE_LIMIT_WINDOW: Optional[float] = 1.0  # Seconds

    # CometNet Reputation Tuning
    COMETNET_REPUTATION_INITIAL: Optional[float] = 100.0
    COMETNET_REPUTATION_MIN: Optional[float] = 0.0
    COMETNET_REPUTATION_MAX: Optional[float] = 10000.0
    COMETNET_REPUTATION_THRESHOLD_UNTRUSTED: Optional[float] = 50.0  # Ban threshold
    COMETNET_REPUTATION_THRESHOLD_TRUSTED: Optional[float] = (
        1000.0  # Trust threshold (approx 1 day of heavy scraping)
    )
    COMETNET_REPUTATION_BONUS_VALID_CONTRIBUTION: Optional[float] = (
        0.001  # 1M torrents = 1000 pts
    )
    COMETNET_REPUTATION_BONUS_PER_DAY_ANCIENNETY: Optional[float] = 10.0
    COMETNET_REPUTATION_BONUS_MAX_ANCIENNETY: Optional[float] = (
        1000.0  # Max 1000 pts from age (100 days)
    )
    COMETNET_REPUTATION_PENALTY_INVALID_CONTRIBUTION: Optional[float] = 50.0
    COMETNET_REPUTATION_PENALTY_INVALID_SIGNATURE: Optional[float] = 500.0

    # CometNet Contribution Mode
    # full: Share own torrents + receive + repropagate (default)
    # consumer: Receive + repropagate, but don't share own torrents
    # source: Share own torrents only (dedicated scraper)
    # leech: Receive only, don't repropagate (save bandwidth)
    COMETNET_CONTRIBUTION_MODE: Optional[str] = "full"

    # CometNet Trust Pools
    # List of pool IDs to subscribe to
    # If empty: accept from everyone (open mode)
    COMETNET_TRUSTED_POOLS: List[str] = []
    # Directory for storing pool manifests and membership data
    COMETNET_POOLS_DIR: Optional[str] = "data/cometnet/pools"

    # CometNet Private Network
    # Isolate this node in a private network
    COMETNET_PRIVATE_NETWORK: Optional[bool] = False
    # Network ID for private network (required if PRIVATE_NETWORK=true)
    COMETNET_NETWORK_ID: Optional[str] = None
    # Password to join the private network (Argon2 hashed for auth)
    COMETNET_NETWORK_PASSWORD: Optional[str] = None
    # Pools to ingest from even when in private mode
    COMETNET_INGEST_POOLS: List[str] = []

    # CometNet Node Alias
    # Optional friendly name for this node (exchanged with other peers)
    # If not set, users will only see the Node ID
    COMETNET_NODE_ALIAS: Optional[str] = None

    @field_validator("EXECUTOR_MAX_WORKERS", mode="before")
    def normalize_executor_workers(cls, v):
        if v is None or v == "" or str(v).lower() == "none":
            return 1
        return v

    @field_validator(
        "CONFIGURE_PAGE_PASSWORD",
        "PUBLIC_API_TOKEN",
        "PUBLIC_API_TOKEN_FILE",
        mode="before",
    )
    def normalize_optional_secrets(cls, v):
        if v is None:
            return None

        normalized = str(v).strip()
        if not normalized or normalized.lower() == "none":
            return None

        return normalized

    @field_validator("INDEXER_MANAGER_TYPE")
    def set_indexer_manager_type(cls, v, values):
        if v is not None and v.lower() == "none":
            return None
        return v

    @field_validator("DATABASE_TYPE", mode="before")
    def normalize_database_type(cls, v):
        if v is None:
            return v

        value = str(v).strip().lower()
        if value in {"postgres", "postgresql", "postgresql+asyncpg", "pgsql", "psql"}:
            return "postgresql"
        if value in {"sqlite", "sqlite3"}:
            return "sqlite"
        return value

    @field_validator(
        "INDEXER_MANAGER_INDEXERS", "JACKETT_INDEXERS", "PROWLARR_INDEXERS"
    )
    def indexer_manager_indexers_normalization(cls, v, values):
        v = [indexer.replace(" ", "").lower() for indexer in v]
        return v

    @field_validator(
        "INDEXER_MANAGER_URL",
        "STREMTHRU_URL",
        "STREMTHRU_SCRAPE_URL",
        "BITMAGNET_URL",
        "COMET_URL",
        "ZILEAN_URL",
        "TORRENTIO_URL",
        "MEDIAFUSION_URL",
        "AIOSTREAMS_URL",
        "JACKETTIO_URL",
        "JACKETT_URL",
        "PROWLARR_URL",
        "PUBLIC_BASE_URL",
    )
    def normalize_urls(cls, v):
        if isinstance(v, str):
            return v.rstrip("/")
        elif isinstance(v, list):
            return [url.rstrip("/") for url in v]
        return v

    def is_scraper_enabled(self, scraper_setting: Union[bool, str], context: str):
        if isinstance(scraper_setting, bool):
            return scraper_setting

        if isinstance(scraper_setting, str):
            scraper_setting = scraper_setting.lower()
            if scraper_setting in ["true", "both"]:
                return True
            elif scraper_setting == context:
                return True

        return False

    def format_scraper_mode(self, scraper_setting: Union[bool, str]):
        if isinstance(scraper_setting, bool):
            return "both" if scraper_setting else "False"

        if isinstance(scraper_setting, str):
            scraper_setting = scraper_setting.lower()
            if scraper_setting in ["true", "both"]:
                return "both"
            elif scraper_setting in ["live", "background"]:
                return scraper_setting

        return "False"

    def is_any_context_enabled(self, scraper_setting: Union[bool, str]):
        if isinstance(scraper_setting, bool):
            return scraper_setting

        if isinstance(scraper_setting, str):
            scraper_setting = scraper_setting.lower()
            return scraper_setting in ["true", "both", "live", "background"]

    def model_post_init(self, __context):
        if self.INDEXER_MANAGER_TYPE == "jackett":
            if not self.SCRAPE_JACKETT:
                self.SCRAPE_JACKETT = self.INDEXER_MANAGER_MODE
            if self.JACKETT_URL == "http://127.0.0.1:9117" and self.INDEXER_MANAGER_URL:
                self.JACKETT_URL = self.INDEXER_MANAGER_URL
            if not self.JACKETT_API_KEY and self.INDEXER_MANAGER_API_KEY:
                self.JACKETT_API_KEY = self.INDEXER_MANAGER_API_KEY
            if not self.JACKETT_INDEXERS and self.INDEXER_MANAGER_INDEXERS:
                self.JACKETT_INDEXERS = self.INDEXER_MANAGER_INDEXERS
        elif self.INDEXER_MANAGER_TYPE == "prowlarr":
            if not self.SCRAPE_PROWLARR:
                self.SCRAPE_PROWLARR = self.INDEXER_MANAGER_MODE
            if (
                self.PROWLARR_URL == "http://127.0.0.1:9696"
                and self.INDEXER_MANAGER_URL
            ):
                self.PROWLARR_URL = self.INDEXER_MANAGER_URL
            if not self.PROWLARR_API_KEY and self.INDEXER_MANAGER_API_KEY:
                self.PROWLARR_API_KEY = self.INDEXER_MANAGER_API_KEY
            if not self.PROWLARR_INDEXERS and self.INDEXER_MANAGER_INDEXERS:
                self.PROWLARR_INDEXERS = self.INDEXER_MANAGER_INDEXERS


def _resolve_persisted_token(
    configured_token: str | None,
    token_file: str | None,
    token_name: str,
):
    if configured_token:
        return configured_token, "env"

    if token_file:
        try:
            token_dir = os.path.dirname(token_file)
            if token_dir:
                os.makedirs(token_dir, exist_ok=True)

            if os.path.exists(token_file):
                with open(token_file, "r", encoding="utf-8") as file:
                    existing_token = file.read().strip()
                    if existing_token:
                        return existing_token, "file"
        except FileNotFoundError:
            pass
        except Exception as error:
            logger.warning(f"Failed to read {token_name}_FILE ({token_file}): {error}")

    generated_token = secrets.token_urlsafe(32)
    if not token_file:
        return generated_token, "generated-memory"

    try:
        fd = os.open(token_file, os.O_WRONLY | os.O_CREAT | os.O_EXCL, 0o600)
        with os.fdopen(fd, "w", encoding="utf-8") as file:
            file.write(generated_token)
        return generated_token, "generated-file"
    except FileExistsError:
        last_read_error: Exception | None = None
        for _ in range(5):
            try:
                with open(token_file, "r", encoding="utf-8") as file:
                    existing_token = file.read().strip()
                    if existing_token:
                        return existing_token, "file"
            except Exception as error:
                last_read_error = error
                logger.warning(
                    f"Failed to read existing {token_name}_FILE ({token_file}): {error}"
                )
            time.sleep(0.05)

        error_context = f"{token_name}_FILE ({token_file}) exists but remained empty or unreadable after retries"
        if last_read_error is not None:
            raise RuntimeError(
                f"{error_context}: {last_read_error}"
            ) from last_read_error
        raise RuntimeError(error_context) from None
    except Exception as error:
        logger.error(f"Failed to persist {token_name}_FILE ({token_file}): {error}")
        raise


def _build_stremio_api_prefix():
    should_protect_api = bool(settings.CONFIGURE_PAGE_PASSWORD) or bool(
        settings.PUBLIC_API_TOKEN
    )
    if not should_protect_api:
        settings.PUBLIC_API_TOKEN_SOURCE = "disabled"
        return ""

    settings.PUBLIC_API_TOKEN, settings.PUBLIC_API_TOKEN_SOURCE = (
        _resolve_persisted_token(
            settings.PUBLIC_API_TOKEN,
            settings.PUBLIC_API_TOKEN_FILE,
            "PUBLIC_API_TOKEN",
        )
    )
    return f"/s/{settings.PUBLIC_API_TOKEN}"


settings = AppSettings()
STREMIO_API_PREFIX = _build_stremio_api_prefix()
settings.STREMIO_API_PREFIX = STREMIO_API_PREFIX

IS_POSTGRES = settings.DATABASE_TYPE == "postgresql"
IS_SQLITE = settings.DATABASE_TYPE == "sqlite"

JSON_FUNC = "json_array_elements_text" if IS_POSTGRES else "json_each"


class CometSettingsModel(SettingsModel):
    model_config = SettingsConfigDict()

    resolutions: ResolutionConfig = ResolutionConfig(
        r2160p=True,
        r576p=True,
        r480p=True,
        r360p=True,
        r240p=True,
    )

    options: OptionsConfig = OptionsConfig(remove_ranks_under=-10000000000)

    languages: LanguagesConfig = LanguagesConfig(exclude=[])

    custom_ranks: CustomRanksConfig = CustomRanksConfig(
        quality=QualityRankModel(
            av1=CustomRank(fetch=True),
            dvd=CustomRank(fetch=True),
            mpeg=CustomRank(fetch=True),
            remux=CustomRank(fetch=True),
            vhs=CustomRank(fetch=True),
            webmux=CustomRank(fetch=True),
            xvid=CustomRank(fetch=True),
        ),
        rips=RipsRankModel(
            bdrip=CustomRank(fetch=True),
            dvdrip=CustomRank(fetch=True),
            ppvrip=CustomRank(fetch=True),
            satrip=CustomRank(fetch=True),
            tvrip=CustomRank(fetch=True),
            uhdrip=CustomRank(fetch=True),
            vhsrip=CustomRank(fetch=True),
            webdlrip=CustomRank(fetch=True),
        ),
        hdr=HdrRankModel(
            dolby_vision=CustomRank(fetch=True),
        ),
        audio=AudioRankModel(
            mono=CustomRank(fetch=True),
            mp3=CustomRank(fetch=True),
        ),
        extras=ExtrasRankModel(
            three_d=CustomRank(fetch=True),
            converted=CustomRank(fetch=True),
            documentary=CustomRank(fetch=True),
            site=CustomRank(fetch=True),
            upscaled=CustomRank(fetch=True),
        ),
    )


rtn_settings_default = CometSettingsModel()
rtn_settings_default_dumped = rtn_settings_default.model_dump()
# {
#     "profile":"default",
#     "require":[

#     ],
#     "exclude":[

#     ],
#     "preferred":[

#     ],
#     "resolutions":{
#         "r2160p":true,
#         "r1080p":true,
#         "r720p":true,
#         "r480p":true,
#         "r360p":true,
#         "unknown":true
#     },
#     "options":{
#         "title_similarity":0.85,
#         "remove_all_trash":true,
#         "remove_ranks_under":-10000000000,
#         "remove_unknown_languages":false,
#         "allow_english_in_languages":false,
#         "enable_fetch_speed_mode":true,
#         "remove_adult_content":true
#     },
#     "languages":{
#         "required":[

#         ],
#         "exclude":[

#         ],
#         "preferred":[

#         ]
#     },
#     "custom_ranks":{
#         "quality":{
#             "av1":{
#                 "fetch":true,
#                 "use_custom_rank":false,
#                 "rank":0
#             },
#             "avc":{
#                 "fetch":true,
#                 "use_custom_rank":false,
#                 "rank":0
#             },
#             "bluray":{
#                 "fetch":true,
#                 "use_custom_rank":false,
#                 "rank":0
#             },
#             "dvd":{
#                 "fetch":true,
#                 "use_custom_rank":false,
#                 "rank":0
#             },
#             "hdtv":{
#                 "fetch":true,
#                 "use_custom_rank":false,
#                 "rank":0
#             },
#             "hevc":{
#                 "fetch":true,
#                 "use_custom_rank":false,
#                 "rank":0
#             },
#             "mpeg":{
#                 "fetch":true,
#                 "use_custom_rank":false,
#                 "rank":0
#             },
#             "remux":{
#                 "fetch":true,
#                 "use_custom_rank":false,
#                 "rank":0
#             },
#             "vhs":{
#                 "fetch":true,
#                 "use_custom_rank":false,
#                 "rank":0
#             },
#             "web":{
#                 "fetch":true,
#                 "use_custom_rank":false,
#                 "rank":0
#             },
#             "webdl":{
#                 "fetch":true,
#                 "use_custom_rank":false,
#                 "rank":0
#             },
#             "webmux":{
#                 "fetch":true,
#                 "use_custom_rank":false,
#                 "rank":0
#             },
#             "xvid":{
#                 "fetch":true,
#                 "use_custom_rank":false,
#                 "rank":0
#             }
#         },
#         "rips":{
#             "bdrip":{
#                 "fetch":true,
#                 "use_custom_rank":false,
#                 "rank":0
#             },
#             "brrip":{
#                 "fetch":true,
#                 "use_custom_rank":false,
#                 "rank":0
#             },
#             "dvdrip":{
#                 "fetch":true,
#                 "use_custom_rank":false,
#                 "rank":0
#             },
#             "hdrip":{
#                 "fetch":true,
#                 "use_custom_rank":false,
#                 "rank":0
#             },
#             "ppvrip":{
#                 "fetch":true,
#                 "use_custom_rank":false,
#                 "rank":0
#             },
#             "satrip":{
#                 "fetch":true,
#                 "use_custom_rank":false,
#                 "rank":0
#             },
#             "tvrip":{
#                 "fetch":true,
#                 "use_custom_rank":false,
#                 "rank":0
#             },
#             "uhdrip":{
#                 "fetch":true,
#                 "use_custom_rank":false,
#                 "rank":0
#             },
#             "vhsrip":{
#                 "fetch":true,
#                 "use_custom_rank":false,
#                 "rank":0
#             },
#             "webdlrip":{
#                 "fetch":true,
#                 "use_custom_rank":false,
#                 "rank":0
#             },
#             "webrip":{
#                 "fetch":true,
#                 "use_custom_rank":false,
#                 "rank":0
#             }
#         },
#         "hdr":{
#             "bit10":{
#                 "fetch":true,
#                 "use_custom_rank":false,
#                 "rank":0
#             },
#             "dolby_vision":{
#                 "fetch":true,
#                 "use_custom_rank":false,
#                 "rank":0
#             },
#             "hdr":{
#                 "fetch":true,
#                 "use_custom_rank":false,
#                 "rank":0
#             },
#             "hdr10plus":{
#                 "fetch":true,
#                 "use_custom_rank":false,
#                 "rank":0
#             },
#             "sdr":{
#                 "fetch":true,
#                 "use_custom_rank":false,
#                 "rank":0
#             }
#         },
#         "audio":{
#             "aac":{
#                 "fetch":true,
#                 "use_custom_rank":false,
#                 "rank":0
#             },
#             "ac3":{
#                 "fetch":true,
#                 "use_custom_rank":false,
#                 "rank":0
#             },
#             "atmos":{
#                 "fetch":true,
#                 "use_custom_rank":false,
#                 "rank":0
#             },
#             "dolby_digital":{
#                 "fetch":true,
#                 "use_custom_rank":false,
#                 "rank":0
#             },
#             "dolby_digital_plus":{
#                 "fetch":true,
#                 "use_custom_rank":false,
#                 "rank":0
#             },
#             "dts_lossy":{
#                 "fetch":true,
#                 "use_custom_rank":false,
#                 "rank":0
#             },
#             "dts_lossless":{
#                 "fetch":true,
#                 "use_custom_rank":false,
#                 "rank":0
#             },
#             "eac3":{
#                 "fetch":true,
#                 "use_custom_rank":false,
#                 "rank":0
#             },
#             "flac":{
#                 "fetch":true,
#                 "use_custom_rank":false,
#                 "rank":0
#             },
#             "mono":{
#                 "fetch":true,
#                 "use_custom_rank":false,
#                 "rank":0
#             },
#             "mp3":{
#                 "fetch":true,
#                 "use_custom_rank":false,
#                 "rank":0
#             },
#             "stereo":{
#                 "fetch":true,
#                 "use_custom_rank":false,
#                 "rank":0
#             },
#             "surround":{
#                 "fetch":true,
#                 "use_custom_rank":false,
#                 "rank":0
#             },
#             "truehd":{
#                 "fetch":true,
#                 "use_custom_rank":false,
#                 "rank":0
#             }
#         },
#         "extras":{
#             "three_d":{
#                 "fetch":true,
#                 "use_custom_rank":false,
#                 "rank":0
#             },
#             "converted":{
#                 "fetch":true,
#                 "use_custom_rank":false,
#                 "rank":0
#             },
#             "documentary":{
#                 "fetch":true,
#                 "use_custom_rank":false,
#                 "rank":0
#             },
#             "dubbed":{
#                 "fetch":true,
#                 "use_custom_rank":false,
#                 "rank":0
#             },
#             "edition":{
#                 "fetch":true,
#                 "use_custom_rank":false,
#                 "rank":0
#             },
#             "hardcoded":{
#                 "fetch":true,
#                 "use_custom_rank":false,
#                 "rank":0
#             },
#             "network":{
#                 "fetch":true,
#                 "use_custom_rank":false,
#                 "rank":0
#             },
#             "proper":{
#                 "fetch":true,
#                 "use_custom_rank":false,
#                 "rank":0
#             },
#             "repack":{
#                 "fetch":true,
#                 "use_custom_rank":false,
#                 "rank":0
#             },
#             "retail":{
#                 "fetch":true,
#                 "use_custom_rank":false,
#                 "rank":0
#             },
#             "site":{
#                 "fetch":true,
#                 "use_custom_rank":false,
#                 "rank":0
#             },
#             "subbed":{
#                 "fetch":true,
#                 "use_custom_rank":false,
#                 "rank":0
#             },
#             "upscaled":{
#                 "fetch":true,
#                 "use_custom_rank":false,
#                 "rank":0
#             },
#             "scene":{
#                 "fetch":true,
#                 "use_custom_rank":false,
#                 "rank":0
#             }
#         },
#         "trash":{
#             "cam":{
#                 "fetch":false,
#                 "use_custom_rank":false,
#                 "rank":0
#             },
#             "clean_audio":{
#                 "fetch":false,
#                 "use_custom_rank":false,
#                 "rank":0
#             },
#             "pdtv":{
#                 "fetch":false,
#                 "use_custom_rank":false,
#                 "rank":0
#             },
#             "r5":{
#                 "fetch":false,
#                 "use_custom_rank":false,
#                 "rank":0
#             },
#             "screener":{
#                 "fetch":false,
#                 "use_custom_rank":false,
#                 "rank":0
#             },
#             "size":{
#                 "fetch":false,
#                 "use_custom_rank":false,
#                 "rank":0
#             },
#             "telecine":{
#                 "fetch":false,
#                 "use_custom_rank":false,
#                 "rank":0
#             },
#             "telesync":{
#                 "fetch":false,
#                 "use_custom_rank":false,
#                 "rank":0
#             }
#         }
#     }
# }
rtn_ranking_default = DefaultRanking()


VALID_DEBRID_SERVICES = [
    "realdebrid",
    "alldebrid",
    "premiumize",
    "torbox",
    "debrider",
    "easydebrid",
    "debridlink",
    "offcloud",
    "pikpak",
]


class DebridServiceEntry(BaseModel):
    service: str
    apiKey: str = ""

    @field_validator("service")
    def check_service(cls, v):
        if v not in VALID_DEBRID_SERVICES:
            raise ValueError(f"Invalid debrid service: {v}")
        return v


class ConfigModel(BaseModel):
    cachedOnly: Optional[bool] = False
    sortCachedUncachedTogether: Optional[bool] = False
    removeTrash: Optional[bool] = True
    resultFormat: Optional[List[str]] = ["all"]
    maxResultsPerResolution: Optional[int] = 0
    maxSize: Optional[float] = 0

    # Legacy single-service fields
    debridService: Optional[str] = "torrent"
    debridApiKey: Optional[str] = ""

    # Multi-Debrid fields
    debridServices: Optional[List[DebridServiceEntry]] = []
    enableTorrent: Optional[bool] = False
    deduplicateStreams: Optional[bool] = False
    scrapeDebridAccountTorrents: Optional[bool] = False

    debridStreamProxyPassword: Optional[str] = ""
    languages: Optional[dict] = rtn_settings_default_dumped["languages"]
    resolutions: Optional[dict] = rtn_settings_default_dumped["resolutions"]
    options: Optional[dict] = rtn_settings_default_dumped["options"]
    rtnSettings: Optional[CometSettingsModel] = rtn_settings_default
    rtnRanking: Optional[DefaultRanking] = rtn_ranking_default

    @field_validator("maxResultsPerResolution")
    def check_max_results_per_resolution(cls, v):
        if not isinstance(v, int):
            v = 0

        if v < 0:
            v = 0
        return v

    @field_validator("maxSize")
    def check_max_size(cls, v):
        if not isinstance(v, float):
            v = 0

        if v < 0:
            v = 0
        return v

    @field_validator("debridService")
    def check_debrid_service(cls, v):
        if v not in VALID_DEBRID_SERVICES + ["torrent"]:
            raise ValueError("Invalid debridService")
        return v

    @field_validator("debridServices", mode="before")
    def validate_debrid_services(cls, v):
        if v is None:
            return []
        if isinstance(v, list):
            return [
                DebridServiceEntry(**entry) if isinstance(entry, dict) else entry
                for entry in v
            ]
        return v


default_config = ConfigModel().model_dump()
default_config["rtnSettings"] = rtn_settings_default
default_config["rtnRanking"] = rtn_ranking_default


web_config = {
    "resolutions": [resolution.value for resolution in RTN.extras.Resolution],
    "resultFormat": [
        "title",
        "video_info",
        "audio_info",
        "quality_info",
        "release_group",
        "seeders",
        "size",
        "tracker",
        "languages",
    ],
}


def _build_database_instance(raw_url: str):
    if IS_SQLITE:
        return Database(f"sqlite:///{raw_url}")

    for scheme in ["postgresql://", "postgres://"]:
        if raw_url.startswith(scheme):
            raw_url = raw_url[len(scheme) :]
            break

    return Database(f"postgresql+asyncpg://{raw_url}")


replica_instances: List[Database] = []
force_ipv4 = False

if IS_SQLITE:
    database_url = settings.DATABASE_PATH
    if settings.DATABASE_READ_REPLICA_URLS:
        logger.log("DATABASE", "Read replicas are ignored for sqlite deployments")
else:
    database_url = settings.DATABASE_URL
    replica_instances = [
        _build_database_instance(url)
        for url in settings.DATABASE_READ_REPLICA_URLS
        if url
    ]
    force_ipv4 = settings.DATABASE_FORCE_IPV4_RESOLUTION and IS_POSTGRES


database = ReplicaAwareDatabase(
    _build_database_instance(database_url),
    replicas=replica_instances,
    force_ipv4=force_ipv4,
)
