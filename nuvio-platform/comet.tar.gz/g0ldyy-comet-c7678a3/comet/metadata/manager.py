import asyncio
import time

import aiohttp
import orjson

from comet.core.database import (build_upsert_assignments, database,
                                 encode_json_param)
from comet.core.logger import logger
from comet.core.models import settings
from comet.services.anime import anime_mapper
from comet.utils.parsing import parse_media_id

from .imdb import get_imdb_metadata
from .kitsu import get_kitsu_metadata
from .trakt import get_trakt_aliases

_CACHE_SELECT_QUERY = """
    SELECT title, year, year_end, aliases_json
    FROM media_metadata_cache
    WHERE media_id = :media_id
    AND metadata_updated_at >= :min_timestamp
"""

_PRESERVE_ALIASES_ON_EMPTY_REFRESH_CONDITION = """
EXCLUDED.aliases_json = '{}'
                AND media_metadata_cache.aliases_json IS NOT NULL
                AND media_metadata_cache.aliases_json != '{}'
"""

_CACHE_INSERT_SQL = """
    INSERT INTO media_metadata_cache (
        media_id,
        title,
        year,
        year_end,
        aliases_json,
        metadata_updated_at
    )
    VALUES (
        :media_id,
        :title,
        :year,
        :year_end,
        :aliases_json,
        :metadata_updated_at
    )
"""

_ALIASES_JSON_UPSERT_ASSIGNMENT = f"""        aliases_json = CASE
            WHEN {_PRESERVE_ALIASES_ON_EMPTY_REFRESH_CONDITION}
            THEN media_metadata_cache.aliases_json
            ELSE EXCLUDED.aliases_json
        END"""

_METADATA_UPDATED_AT_UPSERT_ASSIGNMENT = (
    "        metadata_updated_at = EXCLUDED.metadata_updated_at"
)

_CACHE_STANDARD_METADATA_ASSIGNMENTS = build_upsert_assignments(
    ("title", "year", "year_end")
)

_CACHE_ALIAS_ENRICH_METADATA_ASSIGNMENTS = """
        title = CASE
            WHEN media_metadata_cache.metadata_updated_at IS NULL
                OR media_metadata_cache.metadata_updated_at < :metadata_stale_before
            THEN EXCLUDED.title
            ELSE media_metadata_cache.title
        END,
        year = CASE
            WHEN media_metadata_cache.metadata_updated_at IS NULL
                OR media_metadata_cache.metadata_updated_at < :metadata_stale_before
            THEN EXCLUDED.year
            ELSE media_metadata_cache.year
        END,
        year_end = CASE
            WHEN media_metadata_cache.metadata_updated_at IS NULL
                OR media_metadata_cache.metadata_updated_at < :metadata_stale_before
            THEN EXCLUDED.year_end
            ELSE media_metadata_cache.year_end
        END
""".strip()


def _build_cache_upsert_query(metadata_assignments: str) -> str:
    return f"""
{_CACHE_INSERT_SQL}
    ON CONFLICT (media_id) DO UPDATE SET
{metadata_assignments},
{_ALIASES_JSON_UPSERT_ASSIGNMENT},
{_METADATA_UPDATED_AT_UPSERT_ASSIGNMENT}
    RETURNING aliases_json
"""


_CACHE_UPSERT_RETURNING_QUERY = _build_cache_upsert_query(
    _CACHE_STANDARD_METADATA_ASSIGNMENTS
)
_CACHE_ALIAS_ENRICH_RETURNING_QUERY = _build_cache_upsert_query(
    _CACHE_ALIAS_ENRICH_METADATA_ASSIGNMENTS
)


class MetadataScraper:
    def __init__(self, session: aiohttp.ClientSession):
        self.session = session

    async def fetch_metadata_and_aliases(
        self,
        media_type: str,
        media_id: str,
        id: str | None = None,
        season: int | None = None,
        episode: int | None = None,
    ):
        if id is None:
            id, season, episode = parse_media_id(media_type, media_id)

        provider = self._extract_provider(media_id)
        cache_id = f"{provider}:{id}" if provider else id
        cache_season = 1 if provider == "kitsu" else season

        get_cached = await self.get_cached(cache_id, cache_season, episode)
        if get_cached is not None:
            return get_cached[0], get_cached[1]

        is_kitsu = provider == "kitsu"

        metadata_task = asyncio.create_task(
            self.get_metadata(id, season, episode, is_kitsu, media_type)
        )
        aliases_task = asyncio.create_task(self.get_aliases(media_type, id, provider))
        metadata, aliases = await asyncio.gather(metadata_task, aliases_task)

        if metadata is not None:
            aliases = await self.cache_metadata(cache_id, metadata, aliases)

        return metadata, aliases

    @staticmethod
    def _extract_provider(media_id: str):
        if media_id.startswith("tt"):
            return "imdb"

        first_part, sep, _ = media_id.partition(":")

        if sep:
            return first_part.lower()

        return None

    @staticmethod
    def _load_cached_aliases(aliases_json) -> dict:
        if aliases_json is None:
            return {}

        try:
            aliases = orjson.loads(aliases_json)
        except (TypeError, orjson.JSONDecodeError):
            return {}

        return aliases if isinstance(aliases, dict) else {}

    async def get_cached(self, media_id: str, season: int, episode: int):
        row = await database.fetch_one(
            _CACHE_SELECT_QUERY,
            {
                "media_id": media_id,
                "min_timestamp": time.time() - settings.METADATA_CACHE_TTL,
            },
        )
        if row is None:
            return None

        return (
            {
                "title": row["title"],
                "year": row["year"],
                "year_end": row["year_end"],
                "season": season,
                "episode": episode,
            },
            self._load_cached_aliases(row["aliases_json"]),
        )

    async def cache_metadata(
        self,
        media_id: str,
        metadata: dict,
        aliases: dict,
        preserve_existing_metadata: bool = False,
    ) -> dict:
        current_time = time.time()
        if preserve_existing_metadata:
            query = _CACHE_ALIAS_ENRICH_RETURNING_QUERY
        else:
            query = _CACHE_UPSERT_RETURNING_QUERY
        params = {
            "media_id": media_id,
            "title": metadata["title"],
            "year": metadata["year"],
            "year_end": metadata["year_end"],
            "aliases_json": encode_json_param(aliases),
            "metadata_updated_at": current_time,
        }
        if preserve_existing_metadata:
            params["metadata_stale_before"] = current_time - settings.METADATA_CACHE_TTL

        row = await database.fetch_one(query, params, force_primary=True)
        return self._load_cached_aliases(row["aliases_json"]) if row is not None else {}

    def normalize_metadata(self, metadata: dict, season: int, episode: int):
        if not metadata:
            return None

        title, year, year_end = metadata

        if title is None:  # metadata retrieving failed
            return None

        return {
            "title": title,
            "year": year,
            "year_end": year_end,
            "season": season,
            "episode": episode,
        }

    async def get_metadata(
        self, id: str, season: int, episode: int, is_kitsu: bool, media_type: str
    ):
        if is_kitsu:
            raw_metadata = await get_kitsu_metadata(self.session, id)
            return self.normalize_metadata(raw_metadata, 1, episode)
        else:
            raw_metadata = await get_imdb_metadata(self.session, id, media_type)
            return self.normalize_metadata(raw_metadata, season, episode)

    async def fetch_aliases_with_metadata(
        self,
        media_type: str,
        media_id: str,
        title: str,
        year: int,
        year_end: int = None,
        id: str | None = None,
    ):
        """
        Fetch aliases while reusing provided canonical metadata values.
        It short-circuits on a warm cache, refreshes aliases, refreshes stale canonical
        metadata, and seeds canonical metadata only when none exists.
        """
        if id is None:
            id, _, _ = parse_media_id(media_type, media_id)

        provider = self._extract_provider(media_id)
        cache_id = f"{provider}:{id}" if provider else id

        get_cached = await self.get_cached(cache_id, 1, 1)
        if get_cached is not None:
            return get_cached[0], get_cached[1]

        metadata = {
            "title": title,
            "year": year,
            "year_end": year_end,
        }

        aliases = await self.get_aliases(media_type, id, provider)
        aliases = await self.cache_metadata(
            cache_id,
            metadata,
            aliases,
            preserve_existing_metadata=True,
        )

        return metadata, aliases

    async def get_aliases(
        self,
        media_type: str,
        media_id: str,
        provider: str | None = None,
    ):
        if anime_mapper.is_loaded():
            full_media_id = f"{provider}:{media_id}"

            if anime_mapper.is_anime_content(full_media_id, media_id):
                aliases = await anime_mapper.get_aliases(full_media_id)
                logger.log(
                    "SCRAPER",
                    f"📜 Found {len(aliases.get('ez', []))} Anime title aliases for {media_id}",
                )
                if aliases:
                    return aliases

        if provider == "kitsu":
            logger.log("SCRAPER", f"📜 No Anime title aliases found for {media_id}")
            return {}

        trakt_aliases = await get_trakt_aliases(self.session, media_type, media_id)
        if trakt_aliases:
            total_aliases = sum(len(titles) for titles in trakt_aliases.values())
            logger.log(
                "SCRAPER",
                f"📜 Found {total_aliases} Trakt title aliases for {media_id}",
            )
        else:
            logger.log("SCRAPER", f"📜 No Trakt title aliases found for {media_id}")

        return trakt_aliases
