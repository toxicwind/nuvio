"""
CometNet Gossip Module

Implements the epidemic gossip protocol for propagating torrent metadata
across the network.
"""

import asyncio
import time
from collections import deque
from typing import Awaitable, Callable, Deque, Dict, List, Optional, Set

from comet.cometnet.crypto import NodeIdentity
from comet.cometnet.protocol import TorrentAnnounce, TorrentMetadata
from comet.cometnet.reputation import ReputationStore
from comet.cometnet.utils import run_in_executor
from comet.cometnet.validation import (validate_message_security,
                                       verify_torrent_signature_sync)
from comet.core.logger import logger
from comet.core.models import settings

# Type for the callback to save a torrent to the database
SaveTorrentCallback = Callable[[TorrentMetadata], Awaitable[None]]

# Type for getting random peers
GetRandomPeersCallback = Callable[[int, Optional[Set[str]]], List[str]]

# Type for sending a message to peers
SendMessageCallback = Callable[[str, TorrentAnnounce | bytes], Awaitable[None]]

# Type for broadcasting a message
BroadcastCallback = Callable[[TorrentAnnounce, Optional[Set[str]]], Awaitable[None]]

# Type for disconnecting a peer
DisconnectPeerCallback = Callable[[str], Awaitable[None]]

# Type for checking if torrents exist locally (batch)
CheckTorrentsExistCallback = Callable[[List[str]], Awaitable[Set[str]]]


def sign_object_sync(identity: NodeIdentity, obj: object) -> str:
    """
    Helper to serialize and sign an object synchronously.
    Intended to be run in an executor to offload CPU work.
    """
    return identity.sign_hex(obj.to_signable_bytes())


def batch_sign_objects_sync(identity: NodeIdentity, objects: List[object]) -> List[str]:
    """
    Helper to sign a list of objects in a single executor call.
    """
    return [identity.sign_hex(obj.to_signable_bytes()) for obj in objects]


class GossipEngine:
    """
    Implements the gossip protocol for propagating torrent metadata.

    Key features:
    - Fanout gossip (each node sends to a random subset of peers)
    - Message deduplication
    - Signature verification
    - Reputation-based filtering
    - Contribution modes (full/consumer/source/leech)
    - Pool-based trust filtering
    """

    # Valid contribution modes
    CONTRIBUTION_MODES = {"full", "consumer", "source", "leech"}

    def __init__(
        self,
        identity: NodeIdentity,
        reputation_store: ReputationStore,
        keystore=None,  # Optional PublicKeyStore for signature verification
        pool_store=None,  # PoolStore for trust filtering
    ):
        self.identity = identity
        self.reputation = reputation_store
        self._keystore = keystore
        self._pool_store = pool_store

        # Gossip parameters from settings
        self.fanout = settings.COMETNET_GOSSIP_FANOUT
        self.gossip_interval = settings.COMETNET_GOSSIP_INTERVAL
        self.message_ttl = settings.COMETNET_GOSSIP_MESSAGE_TTL
        self.max_torrents_per_message = (
            settings.COMETNET_GOSSIP_MAX_TORRENTS_PER_MESSAGE
        )

        # Contribution mode determines what we share/receive
        self.contribution_mode = settings.COMETNET_CONTRIBUTION_MODE
        if self.contribution_mode not in self.CONTRIBUTION_MODES:
            logger.warning(
                f"Invalid contribution mode '{self.contribution_mode}', defaulting to 'full'"
            )
            self.contribution_mode = "full"

        # Queue of torrents waiting to be gossiped
        self._outgoing_queue: Deque[TorrentMetadata] = deque(maxlen=10000)

        # Callbacks (set by manager)
        self._get_random_peers: Optional[GetRandomPeersCallback] = None
        self._send_message: Optional[SendMessageCallback] = None
        self._broadcast: Optional[BroadcastCallback] = None
        self._save_torrent: Optional[SaveTorrentCallback] = None
        self._disconnect_peer: Optional[DisconnectPeerCallback] = None
        self._check_torrents_exist: Optional[CheckTorrentsExistCallback] = None

        # Running state
        self._running = False
        self._gossip_task: Optional[asyncio.Task] = None
        self._cleanup_task: Optional[asyncio.Task] = None

        # Statistics
        self.stats = {
            "torrents_received": 0,
            "torrents_propagated": 0,  # Original torrents from this node
            "torrents_repropagated": 0,  # Torrents received and forwarded to others
            "messages_sent": 0,
            "messages_received": 0,
            "invalid_messages": 0,
            "duplicates_ignored": 0,
            "validation_skipped_exists": 0,
            # stats
            "torrents_filtered_untrusted": 0,
            "torrents_filtered_blacklisted": 0,
            "torrents_skipped_mode": 0,
        }

    def set_callbacks(
        self,
        get_random_peers: GetRandomPeersCallback,
        send_message: SendMessageCallback,
        broadcast: BroadcastCallback,
        save_torrent: SaveTorrentCallback,
        disconnect_peer: Optional[DisconnectPeerCallback] = None,
        check_torrents_exist: Optional[CheckTorrentsExistCallback] = None,
    ) -> None:
        """Set the callbacks for network operations."""
        self._get_random_peers = get_random_peers
        self._send_message = send_message
        self._broadcast = broadcast
        self._save_torrent = save_torrent
        self._disconnect_peer = disconnect_peer
        self._check_torrents_exist = check_torrents_exist

    async def start(self) -> None:
        """Start the gossip engine."""
        if self._running:
            return

        self._running = True

        # Start background tasks
        self._gossip_task = asyncio.create_task(self._gossip_loop())
        self._cleanup_task = asyncio.create_task(self._cleanup_loop())

        logger.log("COMETNET", "Gossip engine started")

    async def stop(self) -> None:
        """Stop the gossip engine."""
        self._running = False

        for task in [self._gossip_task, self._cleanup_task]:
            if task:
                task.cancel()
                try:
                    await task
                except asyncio.CancelledError:
                    pass

        logger.log("COMETNET", "Gossip engine stopped")

    async def queue_torrents(
        self, metadata_list: List[TorrentMetadata], pool_id: Optional[str] = None
    ) -> None:
        """
        Queue multiple torrents for gossiping.
        """
        if self.contribution_mode not in ("full", "source"):
            self.stats["torrents_skipped_mode"] += len(metadata_list)
            return

        valid_list = []
        for metadata in metadata_list:
            if not metadata.imdb_id:
                logger.debug(
                    f"Skipping torrent without imdb_id in gossip queue: {metadata.info_hash}"
                )
                continue

            # Sign the torrent with our identity
            metadata.contributor_id = self.identity.node_id
            metadata.contributor_public_key = self.identity.public_key_hex

            # Set pool_id if provided and we're a member
            if pool_id and self._pool_store:
                if self._pool_store.is_member_of(pool_id):
                    metadata.pool_id = pool_id

            valid_list.append(metadata)

        if not valid_list:
            return

        signatures = await run_in_executor(
            batch_sign_objects_sync, self.identity, valid_list
        )

        for metadata, signature in zip(valid_list, signatures):
            metadata.contributor_signature = signature

        # Record contributions
        if self._pool_store:
            # Group by pool_id
            pool_counts = {}
            for metadata in valid_list:
                pool_counts[metadata.pool_id] = pool_counts.get(metadata.pool_id, 0) + 1

            for pid, count in pool_counts.items():
                await self._pool_store.record_contribution(
                    contributor_public_key=self.identity.public_key_hex,
                    pool_id=pid,
                    count=count,
                )

        # Add to outgoing queue
        self._outgoing_queue.extend(valid_list)

    async def queue_torrent(
        self, metadata: TorrentMetadata, pool_id: Optional[str] = None
    ) -> None:
        """
        Queue a torrent for gossiping.
        """
        await self.queue_torrents([metadata], pool_id)

    async def handle_announce(
        self, sender_id: str, announce: TorrentAnnounce, sender_ip: str = None
    ) -> None:
        """
        Handle an incoming torrent announce message.

        This validates, processes, and optionally re-propagates the torrents.
        """
        self.stats["messages_received"] += 1

        # Check sender reputation
        if not self.reputation.is_peer_acceptable(sender_id):
            self.stats["invalid_messages"] += 1
            if self._disconnect_peer:
                await self._disconnect_peer(sender_id)
            return

        # Validate message security (timestamp, sender_id, signature)
        if not await validate_message_security(
            announce, sender_id, self._keystore, self.reputation
        ):
            self.stats["invalid_messages"] += 1
            return

        peer_rep = self.reputation.get_or_create(sender_id)
        peer_rep.messages_received += 1
        peer_rep.update_seen()

        valid_torrents = []
        torrents_to_repropagate = []

        # Batch check for existence
        existing_hashes = set()
        if self._check_torrents_exist and announce.torrents:
            hashes = [t.info_hash for t in announce.torrents]
            if hashes:
                try:
                    existing_hashes = await self._check_torrents_exist(hashes)
                except Exception:
                    pass

        torrents_to_verify = []

        for torrent in announce.torrents:
            # Skip torrents with invalid size (0) without penalizing the peer
            if torrent.size == 0:
                self.stats["invalid_messages"] += 1
                continue

            # Check if we already have this torrent
            # If so, we can skip expensive cryptographic validation
            if torrent.info_hash in existing_hashes:
                self.stats["validation_skipped_exists"] += 1
                if announce.ttl > 1 and self.contribution_mode in (
                    "full",
                    "consumer",
                ):
                    torrents_to_repropagate.append(torrent)
                continue

            # Validate torrent structure
            if not self._validate_torrent(torrent):
                peer_rep.add_invalid_contribution()
                self.stats["invalid_messages"] += 1
                continue

            # Require valid signature and public key on all torrents
            if (
                not torrent.contributor_id
                or not torrent.contributor_signature
                or not torrent.contributor_public_key
            ):
                peer_rep.add_invalid_contribution()
                self.stats["invalid_messages"] += 1
                continue

            torrents_to_verify.append(torrent)

        # Batch verify signatures in executor
        if torrents_to_verify:
            verification_results = await asyncio.gather(
                *[
                    run_in_executor(verify_torrent_signature_sync, t)
                    for t in torrents_to_verify
                ]
            )

            for torrent, is_valid in zip(torrents_to_verify, verification_results):
                if not is_valid:
                    peer_rep.add_invalid_contribution()
                    self.stats["invalid_messages"] += 1
                    continue

                # Check if contributor is trusted (pool-based filtering)
                if self._pool_store:
                    if not self._pool_store.is_contributor_trusted(
                        torrent.contributor_public_key, torrent.pool_id
                    ):
                        self.stats["torrents_filtered_untrusted"] += 1
                        continue

                # Store the contributor key in our keystore for future reference (optional)
                if self._keystore:
                    self._keystore.store_key(
                        node_id=torrent.contributor_id,
                        public_key_hex=torrent.contributor_public_key,
                        verified=True,
                    )

                valid_torrents.append(torrent)

                # Add to re-propagation list if TTL allows
                # Only repropagate if contribution mode allows (full or consumer)
                if announce.ttl > 1 and self.contribution_mode in ("full", "consumer"):
                    torrents_to_repropagate.append(torrent)

        # Update reputation for valid contributions
        if valid_torrents:
            peer_rep.add_valid_contribution(len(valid_torrents))

        # Record contributions in pool store (track member stats)
        if valid_torrents and self._pool_store:
            # Group by contributor to batch the updates
            contributions: Dict[tuple, int] = {}
            for torrent in valid_torrents:
                key = (torrent.contributor_public_key, torrent.pool_id)
                contributions[key] = contributions.get(key, 0) + 1

            # Record each contributor's contributions
            for (contributor_key, pool_id), count in contributions.items():
                await self._pool_store.record_contribution(
                    contributor_public_key=contributor_key,
                    pool_id=pool_id,
                    count=count,
                )

        # Save valid torrents to database
        # Only save if contribution mode allows receiving (not 'source')
        if self._save_torrent and valid_torrents and self.contribution_mode != "source":
            saved_count = 0
            for torrent in valid_torrents:
                try:
                    await self._save_torrent(torrent)
                    self.stats["torrents_received"] += 1
                    saved_count += 1
                except Exception:
                    pass

            if saved_count > 0:
                logger.log(
                    "COMETNET",
                    f"Received {saved_count} torrents from peer {sender_id[:8]}",
                )

        # Re-propagate to other peers (with reduced TTL)
        if torrents_to_repropagate and self._get_random_peers and self._send_message:
            # Add sender and self to visited/exclude list
            current_visited = set(announce.visited_nodes)
            current_visited.add(sender_id)
            current_visited.add(self.identity.node_id)

            # Combine visited nodes with the explicit exclude set
            exclude_set = {sender_id}.union(current_visited)

            peers_reached = await self._repropagate(
                torrents_to_repropagate,
                announce.ttl - 1,
                exclude=exclude_set,
                visited_history=list(current_visited),
            )
            # Track re-propagations separately from original contributions
            if peers_reached > 0:
                self.stats["torrents_repropagated"] += len(torrents_to_repropagate)

        # Check if peer is still acceptable after processing
        if not self.reputation.is_peer_acceptable(sender_id):
            if self._disconnect_peer:
                await self._disconnect_peer(sender_id)

    def _validate_torrent(self, torrent: TorrentMetadata) -> bool:
        """
        Validate a torrent's metadata.

        Returns True if the torrent is valid.
        """
        # Basic validation (Pydantic already does field-level validation)
        try:
            # Verify info_hash format
            if len(torrent.info_hash) != 40:
                return False
            int(torrent.info_hash, 16)

            # Title should be non-empty
            if not torrent.title or len(torrent.title) < 1:
                return False

            # Size should be positive
            if torrent.size <= 0:
                return False

            # Tracker should be non-empty
            if not torrent.tracker:
                return False

            # Local storage requires a media identifier for persistence.
            if not torrent.imdb_id:
                return False

            # Timestamp should be reasonable
            now = time.time()
            if (
                torrent.updated_at
                > now + settings.COMETNET_GOSSIP_VALIDATION_FUTURE_TOLERANCE
            ):  # Future tolerance
                return False
            if (
                torrent.updated_at < now - settings.COMETNET_GOSSIP_TORRENT_MAX_AGE
            ):  # Max age
                return False

            return True
        except (ValueError, TypeError):
            return False

    async def _repropagate(
        self,
        torrents: List[TorrentMetadata],
        ttl: int,
        exclude: Optional[Set[str]] = None,
        visited_history: Optional[List[str]] = None,
    ) -> int:
        """Re-propagate torrents to random peers. Returns the number of peers reached."""
        if not self._get_random_peers or not self._send_message:
            return 0

        # Select random peers
        # Check visited history to avoid loops
        exclude = exclude or set()
        if visited_history:
            exclude.update(visited_history)

        peers = self._get_random_peers(self.fanout, exclude)

        if not peers:
            return 0

        # Create announce message
        announce = TorrentAnnounce(
            sender_id=self.identity.node_id,
            torrents=torrents,
            ttl=ttl,
            visited_nodes=sorted(visited_history or [self.identity.node_id]),
        )

        announce.signature = await run_in_executor(
            sign_object_sync, self.identity, announce
        )

        # Serialize once
        announce_bytes = announce.to_bytes()

        # Send to all selected peers
        async def send_to_peer(peer_id: str) -> bool:
            try:
                await self._send_message(peer_id, announce_bytes)
                return True
            except Exception:
                return False

        results = await asyncio.gather(
            *(send_to_peer(peer_id) for peer_id in peers),
            return_exceptions=True,
        )
        successful_sends = sum(1 for r in results if r is True)
        self.stats["messages_sent"] += successful_sends
        return successful_sends

    async def _gossip_loop(self) -> None:
        """Main gossip loop - periodically sends queued torrents."""
        while self._running:
            try:
                await asyncio.sleep(self.gossip_interval)

                # Check if we have torrents to gossip
                if not self._outgoing_queue:
                    continue

                total_sent = 0
                while self._outgoing_queue:
                    # Take up to MAX_TORRENTS_PER_MESSAGE from queue
                    to_send: List[TorrentMetadata] = []
                    for _ in range(
                        min(self.max_torrents_per_message, len(self._outgoing_queue))
                    ):
                        to_send.append(self._outgoing_queue.popleft())

                    # Create and send announce
                    if self._get_random_peers and self._send_message and to_send:
                        peers_reached = await self._repropagate(
                            to_send, self.message_ttl
                        )
                        # Only count torrents as propagated if at least one peer received them
                        if peers_reached > 0:
                            self.stats["torrents_propagated"] += len(to_send)
                            total_sent += len(to_send)
            except asyncio.CancelledError:
                break
            except Exception:
                pass

    async def _cleanup_loop(self) -> None:
        """Periodically clean up keystore."""
        while self._running:
            try:
                await asyncio.sleep(60.0)

                if self._keystore:
                    self._keystore.cleanup_old_keys(max_age_days=30.0)

                if self.reputation:
                    self.reputation.cleanup_old_peers(max_age_days=30.0)
            except asyncio.CancelledError:
                break
            except Exception:
                pass

    def get_stats(self) -> Dict:
        """Get gossip statistics."""
        return {
            **self.stats,
            "queue_size": len(self._outgoing_queue),
        }

    def to_dict(self) -> Dict:
        """Serialize the gossip engine state for persistence."""
        return {
            "stats": self.stats,
        }

    def from_dict(self, data: Dict) -> None:
        """Load the gossip engine state from a dictionary."""
        if "stats" in data:
            # Update stats but preserve keys that might be missing in older state files
            # or add new keys that are present in the current code
            loaded_stats = data["stats"]
            for key, value in loaded_stats.items():
                if key in self.stats:
                    self.stats[key] = value
