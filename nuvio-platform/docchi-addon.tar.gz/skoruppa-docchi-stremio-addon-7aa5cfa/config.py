import os

from dotenv import load_dotenv

load_dotenv()


class Config:
    """
    Configuration class
    """
    HOST = os.getenv('HOST', os.getenv('FLASK_RUN_HOST', "localhost"))
    PORT = os.getenv('PORT', os.getenv('FLASK_RUN_PORT', "5000"))
    PROXIFY_STREAMS = os.getenv('PROXIFY_STREAMS', 'false').lower() in ('true', '1', 'yes')  # proxify needed streams
    STREAM_PROXY_URL = os.getenv('STREAM_PROXY_URL', "")  # MediaFlow Proxy
    STREAM_PROXY_PASSWORD = os.getenv('STREAM_PROXY_PASSWORD', "")  # MediaFlowProxy API_PASSWORD
    VIP_PATH = os.getenv('VIP_PATH', 'vip')  # Secret path for VIP users with proxy access
    FORCE_VIP_PLAYERS = os.getenv('FORCE_VIP_PLAYERS', 'false').lower() in ('true', '1', 'yes')  # Make VIP-only players available for all users
    MAL_CLIENT_ID = os.getenv('MAL_CLIENT_ID', '')  # MyAnimeList API Client ID
    FANART_API_KEY = os.getenv('FANART_API_KEY', '')  # fanart.tv API key (optional)
    TVDB_API_KEY = os.getenv('TVDB_API_KEY', '')  # TheTVDB API key (v4)
    SIMKL_CLIENT_ID = os.getenv('SIMKL_CLIENT_ID', '')  # Simkl API client ID (for ID mapping fallback)
    OPENROUTER_API_KEY = os.getenv('OPENROUTER_API_KEY', '')  # OpenRouter API key (for AI translation, free tier)

    DEBUG = os.getenv('DEBUG', os.getenv('FLASK_DEBUG', False))
    DATABASE = "/tmp/database.db"
    
    # Redis for anime mapping
    USE_REDIS = os.getenv('USE_REDIS', 'false').lower() in ('true', '1', 'yes')
    REDIS_URL = os.getenv('REDIS_URL', '')

    # Turso for meta cache
    TURSO_URL = os.getenv('TURSO_URL', '')
    TURSO_TOKEN = os.getenv('TURSO_TOKEN', '')

    # Env dependent configs
    if DEBUG in ["1", True, "True"]:  # Local development
        PROTOCOL = "http"
        REDIRECT_URL = f"{HOST}:{PORT}"
    else:  # Production environment
        PROTOCOL = "https"
        REDIRECT_URL = f"{HOST}"