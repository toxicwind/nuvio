import asyncio
import logging
import urllib.parse
import aiohttp
from fastapi import APIRouter, Request, HTTPException
from .manifest import MANIFEST


from app.routes import docchi_client, mapping
from app.utils.stream_utils import respond_with
from app.utils.anime_mapping import get_slug_from_mal_id
from app.utils.player_utils import detect_player, get_player_handler


from config import Config

from app.utils.meta_cache import fetch_and_cache_meta

stream_router = APIRouter()
PROXIFY_STREAMS = Config.PROXIFY_STREAMS


PLAYER_TIMEOUT = 8  # Max seconds per player extraction
PLAYER_TIMEOUT_SLOW = 18  # Extended timeout for slow players (filemoon/byse challenge flow)
_SLOW_PLAYERS = {'filemoon'}

# Background tasks for slow players that timed out (let them finish to warm cache)
_background_tasks: set = set()


async def process_player(session, player, is_vip=False):
    player_hosting = player['player_hosting'].lower()
    detected_player = detect_player(player)

    if detected_player != 'default' and detected_player != player_hosting:
        player_hosting = detected_player

    # Early return if no handler available
    handler = get_player_handler(player_hosting)
    if not handler:
        return None

    stream = {
        'url': None,
        'quality': None,
        'player_hosting': player_hosting,
        'translator_title': player['translator_title'],
        'headers': None
    }
    headers = None
    url = None
    quality = None
    inverted = False

    import time as _time
    _t0 = _time.time()
    status = "ok"

    try:
        translator_title = player.get('translator_title', '')
        # Pass translator to players that support embed origin per translator (e.g. filemoon)
        if player_hosting == 'filemoon':
            coro = handler(session, player['player'], is_vip=is_vip, translator=translator_title)
        else:
            coro = handler(session, player['player'], is_vip=is_vip)

        timeout = PLAYER_TIMEOUT_SLOW if player_hosting in _SLOW_PLAYERS else PLAYER_TIMEOUT

        # For slow players: don't cancel on timeout, let them finish in background (warms cache)
        if player_hosting in _SLOW_PLAYERS:
            task = asyncio.ensure_future(coro)
            try:
                url, quality, headers = await asyncio.wait_for(asyncio.shield(task), timeout=timeout)
            except asyncio.TimeoutError:
                status = "timeout"
                # Let it finish in background to warm attest cache
                _background_tasks.add(task)
                task.add_done_callback(_background_tasks.discard)
        else:
            url, quality, headers = await asyncio.wait_for(coro, timeout=timeout)

        if player_hosting == 'vk' and player.get('isInverted'):
            inverted = True
        if not url and status == "ok":
            status = "no_url"
    except asyncio.TimeoutError:
        status = "timeout"
    except Exception as e:
        status = "error"

    elapsed = (_time.time() - _t0) * 1000
    logging.info(f"[Player] {player_hosting}: {status} in {elapsed:.0f}ms")

    stream.update({'url': url, 'quality': quality, 'headers': headers, 'inverted': inverted})
    return stream


def build_filename(anime_name, episode_num, content_id, quality, translator_norm):
    """Build filename for stream."""
    if anime_name:
        name_norm = anime_name.replace(' ', '_').replace(':', '').replace('/', '')
        if episode_num:
            return f"{name_norm}.e{episode_num.zfill(2)}.POL.{quality}-{translator_norm}.docc"
        return f"{name_norm}.POL.{quality}-{translator_norm}.docc"

    # Fallback to content_id
    parts = content_id.split(':')
    content_base = f"{parts[0]}:{parts[1]}"
    if episode_num:
        return f"{content_base}.e{episode_num.zfill(2)}.POL.{quality}-{translator_norm}.docc"
    return f"{content_base}.POL.{quality}-{translator_norm}.docc"


def build_binge_group(anime_name, content_id, quality, translator_norm):
    """Build bingeGroup identifier (same as filename but without episode number)."""
    if anime_name:
        name_norm = anime_name.replace(' ', '_').replace(':', '').replace('/', '')
        return f"{name_norm}.{quality}-{translator_norm}.docc"

    # Fallback to content_id
    parts = content_id.split(':')
    content_base = f"{parts[0]}:{parts[1]}"
    return f"{content_base}.{quality}-{translator_norm}.docc"


async def process_players(players, content_id=None, content_type='series', is_vip=False):
    streams = {'streams': []}

    parts = content_id.split(':') if content_id else []
    episode_num = parts[-1] if len(parts) > 2 else None

    timeout = aiohttp.ClientTimeout(total=None, connect=5)
    connector = aiohttp.TCPConnector(limit=15, limit_per_host=5, ttl_dns_cache=300, verify_ssl=False)

    async with aiohttp.ClientSession(timeout=timeout, connector=connector) as session:
        tasks = [process_player(session, player, is_vip) for player in players]

        # Fetch meta in parallel with player extraction (for filename/bingeGroup)
        meta_task = asyncio.ensure_future(fetch_and_cache_meta(content_id, is_vip)) if content_id else None

        player_results = await asyncio.gather(*tasks)
        valid_streams = [s for s in player_results if s and s['url']]

        anime_name = None
        if valid_streams and meta_task:
            try:
                meta, _ = await asyncio.wait_for(meta_task, timeout=2)
                anime_name = meta.get('name') if meta else None
            except Exception:
                pass
        elif meta_task:
            meta_task.cancel()

        for stream in valid_streams:
            translator = stream['translator_title'] or 'unknown'
            quality = stream['quality'] or 'unknown'
            player = stream['player_hosting']
            is_ai = translator.lower() == 'ai'

            translator_norm = translator.replace(' ', '_').replace('.', '_')
            filename = build_filename(anime_name, episode_num, content_id, quality, translator_norm)
            binge_group = build_binge_group(anime_name, content_id, quality, translator_norm)

            translator_flag = f"🇵🇱 {'⚠️ ' if is_ai else ''}{translator}"
            description = f"{translator_flag}\n🔗 {player}"
            if stream['inverted']:
                description += "\n⚠️ Inverted"

            priority = sort_priority(stream)

            stream_data = {
                'name': quality,
                'description': description,
                'url': stream['url'],
                'behaviorHints': {
                    'filename': filename,
                    'bingeGroup': binge_group
                },
                '_priority': priority
            }

            if player == 'uqload' and PROXIFY_STREAMS:
                stream_data['behaviorHints']['notWebReady'] = True
            if stream.get('headers'):
                stream_data['behaviorHints'].update({
                    'proxyHeaders': stream['headers'],
                    'notWebReady': True
                })

            streams['streams'].append(stream_data)

    # Sort by priority and remove internal field
    streams['streams'] = sorted(streams['streams'], key=lambda d: d['_priority'])
    for stream in streams['streams']:
        stream.pop('_priority', None)

    # Check if any players failed (timeout/error) — signal shorter cache
    total_players = len(players)
    successful = len(valid_streams)
    streams['_had_failures'] = successful < total_players

    return streams


def _quality_bonus(quality: str) -> float:
    """Lower value = higher priority. Subtract bonus for better quality."""
    q = (quality or '').lower().replace('p', '')
    try:
        res = int(q)
    except ValueError:
        return 0
    if res >= 1080:
        return -1.5
    if res >= 720:
        return -1.0
    if res >= 480:
        return -0.5
    return 0


def sort_priority(stream):
    base = 4
    if 'lycoris' in stream['player_hosting']:
        base = 0
    elif stream['player_hosting'] == 'rumble':
        base = 1
    elif stream['player_hosting'] == 'gdrive':
        base = 2
    elif stream['player_hosting'] == 'cda':
        base = 3
    elif stream['player_hosting'] == 'uqload':
        base = 5
    elif stream['player_hosting'] == 'streamtape':
        base = 6
    elif stream['translator_title'].lower() == 'ai':
        base = 9
    return base + _quality_bonus(stream.get('quality'))


@stream_router.get('/stream/{content_type}/{content_id}.json')
async def addon_stream(request: Request, content_type: str, content_id: str):
    """
    Provide url streams for web players
    """
    is_vip = Config.VIP_PATH in request.url.path

    content_id = urllib.parse.unquote(content_id)
    parts = content_id.split(":")

    if content_type not in MANIFEST['types']:
        raise HTTPException(status_code=404)

    prefix = parts[0]
    season = None
    episode = '1'

    # Handle different ID formats
    if prefix.startswith('tt') and is_vip:
        if len(parts) == 1:
            episode = '1'
        elif len(parts) == 3:
            season = int(parts[1])
            episode = int(parts[2])

        prefix_id = mapping.get_mal_id_from_imdb_id(prefix, season)
        # If season > 1 and no direct mapping, try resolving via AniList SEQUEL chain
        if not prefix_id and season and season > 1:
            base_mal_id = mapping.get_mal_id_from_imdb_id(prefix, 1)
            if base_mal_id:
                from app.api.anilist import get_tv_sequel_mal_id
                prefix_id = await get_tv_sequel_mal_id(int(base_mal_id), season - 1)
                if prefix_id:
                    prefix_id = str(prefix_id)
        if prefix_id:
            prefix = 'mal'
        else:
            return respond_with({'streams': []}, 2592000)
    elif prefix == 'kitsu':
        prefix_id = parts[1]
        prefix_id = mapping.get_mal_id_from_kitsu_id(prefix_id)
        if prefix_id:
            prefix = 'mal'
            episode = parts[2] if len(parts) > 2 else '1'
        else:
            return respond_with({'streams': []})

    else:
        prefix_id = parts[1]
        episode = parts[2] if len(parts) > 2 else '1'

    if prefix != 'mal':
        return respond_with({'streams': []}, 2592000)

    slug = await get_slug_from_mal_id(prefix_id)

    players = await docchi_client.get_episode_players(slug, episode)
    if players:
        # Remove duplicates based on 'player' field
        seen = set()
        unique_players = []
        for player in players:
            player_url = player.get('player')
            if player_url and player_url not in seen:
                seen.add(player_url)
                unique_players.append(player)

        streams = await process_players(unique_players, content_id, content_type, is_vip)
        cache_time = 20 if streams.pop('_had_failures', False) else 600
        return respond_with(streams, cache_time)
    return respond_with({'streams': []})
