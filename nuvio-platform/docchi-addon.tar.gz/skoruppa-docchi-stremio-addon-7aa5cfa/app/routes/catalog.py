import urllib.parse
import asyncio
import logging

import aiohttp
from aiocache import Cache
from aiocache.decorators import cached as aiocached
from fastapi import APIRouter, Request, HTTPException

from app.routes import docchi_client
from app.utils.anime_mapping import get_mal_id_from_slug, save_mal_slug_mapping
from app.utils.stream_utils import respond_with, log_error
from app.utils.meta_cache import build_genre_links, fetch_and_cache_meta, with_genre_links, batch_fetch_and_cache_meta
from .manifest import MANIFEST, genres as manifest_genres

from config import Config

catalog_router = APIRouter()

# In-memory aiocache instance for catalog responses
_catalog_cache = Cache(Cache.MEMORY, ttl=600, namespace="catalog")


def _is_valid_catalog(catalog_type: str, catalog_id: str):
    """
    Check if the catalog type and id are valid
    """
    if catalog_type in MANIFEST['types']:
        for catalog in MANIFEST['catalogs']:
            if catalog['id'] == catalog_id or catalog_id == 'winter_2025':
                return True
    return False


async def _process_latest_anime(results):
    """
    Get only unique anime and add mal ids to them
    """
    if not results:
        return []

    unique_anime = {}
    for anime in results:
        anime_id = anime.get("anime_id") or anime.get("slug")
        if anime_id not in unique_anime:
            unique_anime[anime_id] = {
                "slug": anime_id,
                "cover": anime.get("cover"),
                "title": anime.get("title"),
                "title_en": anime.get("title_en")
            }
    unique_anime_list = list(unique_anime.values())

    async def _resolve_mal_id(u_anime):
        try:
            mal_id = await get_mal_id_from_slug(u_anime['slug'])
            if mal_id:
                u_anime['mal_id'] = mal_id
        except Exception as e:
            logging.error(f"Failed to get anime details for {u_anime['slug']}: {e}")

    await asyncio.gather(*[_resolve_mal_id(a) for a in unique_anime_list])
    return unique_anime_list


def _set_cache_time(catalog_id):
    if catalog_id == 'search_list':
        cache_time = 3600
    elif catalog_id in ('newest', 'latest'):
        cache_time = 300
    elif catalog_id in ('season', 'trending'):
        cache_time = 10800
    else:
        cache_time = 0

    return cache_time


async def _fetch_anime_list(search, catalog_id, genre=None):
    season, season_year = docchi_client.get_current_season()

    if search:
        search = urllib.parse.unquote(search)
    if search and not genre:
        if len(search) < 3:
            return []
        return await docchi_client.search_anime(name=search)
    if genre:
        results = await docchi_client.get_anime_by_genre(genre=genre)
        if not results:
            return []
        if search:
            if len(search) < 3:
                return []
            return list(filter(lambda x: search.lower() in x["title"].lower(), results))
        return results
    if catalog_id == 'latest':
        latest = await docchi_client.get_latest_episodes(season, season_year)
        if not latest:
            return []
        return await _process_latest_anime(latest)
    elif catalog_id == 'newest':
        recent = await docchi_client.get_recent_episodes(season, season_year)
        if not recent:
            return []
        return await _process_latest_anime(recent)
    elif catalog_id == "trending":
        trending = await docchi_client.get_trending_anime()
        if not trending:
            return []
        return await _process_latest_anime(trending)
    elif catalog_id == "season":
        return await docchi_client.get_seasonal_anime(season, season_year)
    return []


@catalog_router.get('/catalog/{catalog_type}/{catalog_id}.json')
@catalog_router.get('/catalog/{catalog_type}/{catalog_id}/search={search}.json')
@catalog_router.get('/catalog/{catalog_type}/{catalog_id}/genre={genre}.json')
@catalog_router.get('/catalog/{catalog_type}/{catalog_id}/genre={genre}&search={search}.json')
async def addon_catalog(
    request: Request,
    catalog_type: str,
    catalog_id: str,
    genre: str = None,
    search: str = None
):
    """
    Provides a list of anime
    """
    if not _is_valid_catalog(catalog_type, catalog_id):
        raise HTTPException(status_code=404)

    cache_time = _set_cache_time(catalog_id)
    is_vip = Config.VIP_PATH in request.url.path

    # Check aiocache
    cache_key = f"{catalog_type}:{catalog_id}:{genre}:{search}:{is_vip}"
    cached = await _catalog_cache.get(cache_key)
    if cached is not None:
        return respond_with(cached, cache_time)

    try:
        response_data = await _fetch_anime_list(search, catalog_id, genre)

        content_ids = [f"mal:{item['mal_id']}" for item in response_data if item.get('mal_id')]
        batch_results = await batch_fetch_and_cache_meta(content_ids, is_vip)

        meta_previews = [
            batch_results.get(f"mal:{item['mal_id']}") or docchi_to_meta(item, is_vip, catalog_id)
            for item in response_data
        ]

        result = {'metas': list(meta_previews)}
        if cache_time:
            await _catalog_cache.set(cache_key, result, ttl=cache_time)
        return respond_with(result, cache_time)
    except ValueError as e:
        return respond_with({'metas': [], 'message': str(e)})
    except aiohttp.ClientError as e:
        log_error(e)
        return respond_with({'metas': []}, cache_time)


def docchi_to_meta(anime_item: dict, is_vip: bool = False, catalog_id: str = 'season'):
    content_id = anime_item.get('mal_id', None)
    save_mal_slug_mapping(content_id, anime_item.get('slug', None))

    anime_item_genres = list(anime_item.get('genres', []))
    filtered_genres = list(filter(lambda y: y in manifest_genres, anime_item_genres))

    if media_type := anime_item.get('series_type', '').lower():
        if media_type in ['ona', 'ova', 'special', 'tv', 'unknown', 'tv special']:
            media_type = 'series'
    if not media_type:
        media_type = 'series'

    meta = {
        'id': f"mal:{content_id}" if content_id else None,
        'name': anime_item.get('title', None),
        'type': media_type,
        'genres': filtered_genres,
        'links': [],
        'poster': anime_item.get('cover', {}),
    }
    build_genre_links(meta, is_vip, catalog_id=catalog_id)
    return meta
